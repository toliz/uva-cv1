import math
import numpy as np


def gauss1D(sigma, kernel_size):
	...


def gauss2D(sigma, kernel_size):
	...


def createGabor():
	...
