%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Down load CIFAR-10 and STL-10 and extract to your data path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CIFAR-10: https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz
STL-10: http://ai.stanford.edu/~acoates/stl10/stl10_binary.tar.gz
